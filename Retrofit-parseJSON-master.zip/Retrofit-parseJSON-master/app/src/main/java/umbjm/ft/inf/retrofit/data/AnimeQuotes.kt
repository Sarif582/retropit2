package umbjm.ft.inf.retrofit.data

import com.google.gson.annotations.SerializedName
import javax.annotation.Generated

@Generated("com.hobbyhorse.neurodegeneration")
data class AnimeQuotes(

	@field:SerializedName("character")
	val character: String? = null,

	@field:SerializedName("quote")
	val quote: String? = null,

	@field:SerializedName("anime")
	val anime: String? = null,

)
